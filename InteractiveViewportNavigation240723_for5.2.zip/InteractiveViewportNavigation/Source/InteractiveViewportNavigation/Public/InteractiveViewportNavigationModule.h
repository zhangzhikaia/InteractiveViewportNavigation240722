// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"


class SNavigationManagerWidget;

class FInteractiveViewportNavigationModule : public IModuleInterface
{
public:
	static FString InteractiveToolName;

	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
	
	static FInteractiveViewportNavigationModule& Get(){return FModuleManager::LoadModuleChecked<FInteractiveViewportNavigationModule>(TEXT("InteractiveViewportNavigation"));}
	TSharedPtr<SNavigationManagerWidget> GetManagerWidget(){return ManagerWidget;}
	

private:
	//注册一个视口顶部开关, 在模组开始即执行
	void RegisterViewportTitleButton();
	//注销视口顶板开关, 退出时执行
	static void UnregisterViewportTitleButton();
	//构造视口顶部开关widget, 并且绑定后续事件
	TSharedRef<SWidget> OnExtendLevelEditorViewportToolbar(FWeakObjectPtr ExtensionContext);

	//注册导航交互行为, 在开关开启时执行
	void StartInteractiveNavigationBehavior();
	//注销导航交互行为, 在开关关闭时执行, 退出引擎时不能执行, 会崩溃
	void EndInteractiveNavigationBehavior();

	//注册在切换地图时,开启导航, 因为注册过的导航在切换地图时需重新开启. 开启开关时执行
	//新关卡不会改变导航开关的状态, 故不用检查, 直接开启交互
	void RegisterOnMapChanged();
	//注销切换地图时开启导航, 开关关闭, 退出引擎时执行, 因为退出时开关可能是开的
	void UnregisterOnMapChanged();

	//在进入Play In Editor时, 要关闭导航(后续开发运行时 , 仅在开启按钮时注册
	//离开Play In Editor时, 开启导航, 仅在开启按钮时注册
	void RegisterOnChangedPIE();
	//关闭按钮或结束引擎时注销
	void UnregisterOnChangedPIE();
	
	//绘制导航widget, 开关开启时执行
	void DrawInteractiveNavigation();
	//销毁导航widget, 开关关闭,退出引擎时执行, 因为退出时开关可能是开的
	void DestroyInteractiveNavigation();
	//获取屏幕构造导航widget位置的插槽, 构造即消耗导航时检查
	bool CheckViewportVerticalBox();

	//保存屏幕构造导航widget位置的插槽
	TSharedPtr<SVerticalBox> ViewportVerticalBox;
	//保存导航widget
	TSharedPtr<SNavigationManagerWidget> ManagerWidget;

	//保存切换map的委托, 在注销时使用
	FDelegateHandle OnMapChangedDelegate;
	FDelegateHandle OnMapSavedDelegate;
	FDelegateHandle OnPIEStartedDelegate;
	FDelegateHandle OnPIEEndedDelegate;

	//导航交互行为是否已注册, 若已注册, 不用再次注册, 只开启就行, 因为在切换地图时需重新开启
	//只要注册过一次, 即使关闭也不注销 ,退出引擎也不注销, 会崩溃
	bool bInteractiveNavigationBehaviorRegistered = false;

	//bool bIsMapChangedInPIE = false;
};
