﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "SNavigationManagerWidget.h"

#include "InteractiveNavigationUtils.h"
#include "SDirectionIndicatorWidget.h"
#include "Slate/SlateBrushAsset.h"
#include "Widgets/Layout/SScaleBox.h"
#include "IAssetViewport.h"
#include "LevelEditor.h"
#include "VectorTypes.h"
#include "EditorGizmos/TransformGizmo.h"


void SNavigationManagerWidget::Construct(const FArguments& InArgs)
{
	//只在初始化时设置该缩放倍数, 因为用户几乎不可能在使用引擎途中调整系统DPI,即使调整,重新构造即可. 若要实时判断, 性能消耗浪费
	FDisplayMetrics DisplayMetrics;
	FDisplayMetrics::RebuildDisplayMetrics(DisplayMetrics);

	TArray<FMonitorInfo>& MonitorInfoArray = DisplayMetrics.MonitorInfo;
	//只获取屏幕0的DPI, 因为用户几乎不可能设置两块屏幕为不同的DPI, 尽管有这种可能性
	ScaleBasedDPI = (float)MonitorInfoArray[0].DPI / 96.f;
	LocalOffsetToCenter = OffsetToCenter * ScaleBasedDPI;
	LocalRange = 100.f * ScaleBasedDPI * ScaleBasedDPI;
	
	USlateBrushAsset* SlateBrushPositive = LoadObject<USlateBrushAsset>(nullptr, TEXT("/InteractiveViewportNavigation/SB_SpherePositive"));
	FSlateBrush* BrushPositive = SlateBrushPositive!=nullptr ? &SlateBrushPositive->Brush : new FSlateBrush();
	
	USlateBrushAsset* SlateBrushNegative = LoadObject<USlateBrushAsset>(nullptr, TEXT("/InteractiveViewportNavigation/SB_SphereNegative"));
	FSlateBrush* BrushNegative = SlateBrushNegative!=nullptr ? &SlateBrushNegative->Brush : new FSlateBrush();
	
	FEditorViewportClient* EditorViewportClient =
		&FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor")).GetFirstActiveViewport()->GetAssetViewportClient();

	AxisSlots.SetNumUninitialized(ElementsNum);
	
	TSharedPtr<SDirectionIndicatorWidget> NavigationElementX;
	FOverlaySlot* SlotAxisX = AddSlot()
	[
		SNew(SScaleBox)
		.Stretch(EStretch::ScaleToFit)
		.HAlign(HAlign_Right)
		[
			//DirectionIndicator.ToSharedRef()
			SAssignNew(NavigationElementX,SDirectionIndicatorWidget)
			.SetBrush(BrushPositive)
			.SetEditorViewportClient(EditorViewportClient)
			.SetAxisDirection(FVector(AxisLength,0.f,0.f))
			.SetAxisColor(FLinearColor::FromPow22Color(DIAxisColorX))
			.SetAxisText(FString(TEXT("X")))
			.SetPartIdentifier(static_cast<uint32>(ETransformGizmoPartIdentifier::TranslateXAxis))
			.SetIsPositive(true)
		]
	].GetSlot();
	NavigationElements.Add(NavigationElementX);
	AxisSlots[0] = SlotAxisX;
	
	TSharedPtr<SDirectionIndicatorWidget> NavigationElementY;
	FOverlaySlot* SlotAxisY = AddSlot()
	[
		SNew(SScaleBox)
		.Stretch(EStretch::ScaleToFit)
		.HAlign(HAlign_Right)
		[
			//DirectionIndicator.ToSharedRef()
			SAssignNew(NavigationElementY,SDirectionIndicatorWidget)
			.SetBrush(BrushPositive)
			.SetEditorViewportClient(EditorViewportClient)
			.SetAxisDirection(FVector(0.f,AxisLength,0.f))
			.SetAxisColor(FLinearColor::FromPow22Color(DIAxisColorY))
			.SetAxisText(FString(TEXT("Y")))
			.SetPartIdentifier(static_cast<uint32>(ETransformGizmoPartIdentifier::TranslateYAxis))
			.SetIsPositive(true)
		]
	].GetSlot();
	NavigationElements.Add(NavigationElementY);
	AxisSlots[1] = SlotAxisY;
	
	TSharedPtr<SDirectionIndicatorWidget> NavigationElementZ;
	FOverlaySlot* SlotAxisZ = AddSlot()
	[
		SNew(SScaleBox)
		.Stretch(EStretch::ScaleToFit)
		.HAlign(HAlign_Right)
		[
			//DirectionIndicator.ToSharedRef()
			SAssignNew(NavigationElementZ,SDirectionIndicatorWidget)
			.SetBrush(BrushPositive)
			.SetEditorViewportClient(EditorViewportClient)
			.SetAxisDirection(FVector(0.f,0.f,AxisLength))
			.SetAxisColor(FLinearColor::FromPow22Color(DIAxisColorZ))
			.SetAxisText(FString(TEXT("Z")))
			.SetPartIdentifier(static_cast<uint32>(ETransformGizmoPartIdentifier::TranslateZAxis))
			.SetIsPositive(true)
		]
	].GetSlot();
	NavigationElements.Add(NavigationElementZ);
	AxisSlots[2] = SlotAxisZ;
	
	TSharedPtr<SDirectionIndicatorWidget> NavigationElement_X;
	FOverlaySlot* SlotAxis_X = AddSlot()
	[
		SNew(SScaleBox)
		.Stretch(EStretch::ScaleToFit)
		.HAlign(HAlign_Right)
		[
		
			SAssignNew(NavigationElement_X,SDirectionIndicatorWidget)
			.SetBrush(BrushNegative)
			.SetEditorViewportClient(EditorViewportClient)
			.SetAxisDirection(FVector(-AxisLength,0.f,0.f))
			.SetAxisColor(FLinearColor::FromPow22Color(DIAxisColorX))
			.SetAxisText(FString(TEXT("-X")))
			.SetPartIdentifier(static_cast<uint32>(ETransformGizmoPartIdentifier::RotateXAxis))
			.SetIsPositive(false)
		]
	].GetSlot();
	NavigationElements.Add(NavigationElement_X);
	AxisSlots[3] = SlotAxis_X;

	TSharedPtr<SDirectionIndicatorWidget> NavigationElement_Y;
	FOverlaySlot* SlotAxis_Y = AddSlot()
	[
		SNew(SScaleBox)
		.Stretch(EStretch::ScaleToFit)
		.HAlign(HAlign_Right)
		[
		
			SAssignNew(NavigationElement_Y,SDirectionIndicatorWidget)
			.SetBrush(BrushNegative)
			.SetEditorViewportClient(EditorViewportClient)
			.SetAxisDirection(FVector(0.f,-AxisLength,0.f))
			.SetAxisColor(FLinearColor::FromPow22Color(DIAxisColorY))
			.SetAxisText(FString(TEXT("-Y")))
			.SetPartIdentifier(static_cast<uint32>(ETransformGizmoPartIdentifier::RotateYAxis))
			.SetIsPositive(false)
		]
	].GetSlot();
	NavigationElements.Add(NavigationElement_Y);
	AxisSlots[4] = SlotAxis_Y;

	TSharedPtr<SDirectionIndicatorWidget> NavigationElement_Z;
	FOverlaySlot* SlotAxis_Z = AddSlot()
	[
		SNew(SScaleBox)
		.Stretch(EStretch::ScaleToFit)
		.HAlign(HAlign_Right)
		[
		
			SAssignNew(NavigationElement_Z,SDirectionIndicatorWidget)
			.SetBrush(BrushNegative)
			.SetEditorViewportClient(EditorViewportClient)
			.SetAxisDirection(FVector(0.f,0.f,-AxisLength))
			.SetAxisColor(FLinearColor::FromPow22Color(DIAxisColorZ))
			.SetAxisText(FString(TEXT("-Z")))
			.SetPartIdentifier(static_cast<uint32>(ETransformGizmoPartIdentifier::RotateZAxis))
			.SetIsPositive(false)
		]
	].GetSlot();
	NavigationElements.Add(NavigationElement_Z);
	AxisSlots[5] = SlotAxis_Z;
	
	//以0元素初始化, 避免出现未初始化的值
	SortDepth.SetNumZeroed(ElementsNum);
	
	SetCanTick(true);
}

void SNavigationManagerWidget::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{
	//按深度排序
	for (int i = 0; i < ElementsNum; ++i)
	{
		SortDepth[i] = TPair<float,FOverlaySlot*>(NavigationElements[i]->GetLoaclDepth(),AxisSlots[i]);
	}
	
	SortDepth.Sort();

	for(int i = 0; i < ElementsNum; ++i)
	{
		SortDepth[i].Value->SetZOrder(ElementsNum-i);
	}
	
	SOverlay::Tick(AllottedGeometry, InCurrentTime, InDeltaTime);
	
}

TSharedRef<SScaleBox> SNavigationManagerWidget::MakeNavigationElement(TSharedPtr<SDirectionIndicatorWidget> NavigationElement, FSlateBrush* InBrush,FEditorViewportClient* EditorViewportClient, FVector AxisDirection, FColor AxisColor, FString ShowText, ETransformGizmoPartIdentifier PartIdentifier)
{
	//调用报错
	TSharedPtr<SScaleBox> ScaleBox = SNew(SScaleBox)
	.Stretch(EStretch::ScaleToFit)
	.HAlign(HAlign_Center)
	[
		//DirectionIndicator.ToSharedRef()
		SAssignNew(NavigationElement,SDirectionIndicatorWidget)
		.SetBrush(InBrush)
		.SetEditorViewportClient(EditorViewportClient)
		.SetAxisDirection(AxisDirection * AxisLength)
		.SetAxisColor(FLinearColor::FromPow22Color(AxisColor))
		.SetAxisText(ShowText)
		.SetPartIdentifier(static_cast<uint32>(PartIdentifier))
	];
	return ScaleBox.ToSharedRef();
}

FInputRayHit SNavigationManagerWidget::IsHit(const UE::Slate::FDeprecateVector2DResult& MouseScreenPos)
{
	FInputRayHit Hit;
	for(TSharedPtr<SDirectionIndicatorWidget> Current : NavigationElements)
	{
		if(Current.IsValid())
		{
			//todo:这里需要检查所有, 找到最前的
			const FInputRayHit NewHit = Current->IsHit(MouseScreenPos);
			if ((!Hit.bHit || NewHit.HitDepth < Hit.HitDepth) && NewHit.bHit)
			{
				Hit = NewHit;
			}
		}
	}
	
	return Hit;
}

void SNavigationManagerWidget::UpdateHoverState(bool bHovering, uint32 PartIdentifier)
{
	for(TSharedPtr<SDirectionIndicatorWidget> Current : NavigationElements)
	{
		if(Current.IsValid())
		{
			Current->UpdateHoverState(bHovering,PartIdentifier);
		}
	}
}