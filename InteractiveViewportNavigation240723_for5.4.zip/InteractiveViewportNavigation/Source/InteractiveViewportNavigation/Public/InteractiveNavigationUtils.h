﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.
#pragma once

#include "Kismet/KismetStringLibrary.h"

#if 0
namespace Debug
{
	static void Print(const FString& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, message);
		}
		UE_LOG(LogTemp,Warning,TEXT("%s"),*message);
	}
	static void Print(const int32& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, FString::FromInt(message));
		}
		UE_LOG(LogTemp,Warning,TEXT("%i"),message);
	}
	static void Print(const double& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, UKismetStringLibrary::Conv_DoubleToString(message));
		}
		UE_LOG(LogTemp,Warning,TEXT("%f"),message);
	}
	static void Print(const FText& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, message.ToString());
		}
		UE_LOG(LogTemp,Warning,TEXT("%s"),*message.ToString());
	}
	static void Print(const FVector& InVector, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, InVector.ToString());
		}
		UE_LOG(LogTemp,Warning,TEXT("%s"),*InVector.ToString());
	}
	static void Print(const FRotator& InRotator, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, InRotator.ToString());
		}
		UE_LOG(LogTemp,Warning,TEXT("%s"),*InRotator.ToString());
	}
	static void Print(const FLinearColor& InColor, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, InColor.ToString());
		}
		UE_LOG(LogTemp,Warning,TEXT("%s"),*InColor.ToString());
	}
	static void Print(const FVector3f& InVector, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, InVector.ToString());
		}
		UE_LOG(LogTemp,Warning,TEXT("%s"),*InVector.ToString());
	}
	static void FastPrint()
	{
		Print(TEXT("FastPring : Debug"));
		UE_LOG(LogTemp,Warning,TEXT("FastPring : Debug"));
	}
}
#endif